package com.v3ecommerce.v3_ecommerce;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class V3EcommerceApplication {

	public static void main(String[] args) {
		SpringApplication.run(V3EcommerceApplication.class, args);
	}

}
