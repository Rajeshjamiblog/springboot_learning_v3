package com.v3ecommerce.v3_ecommerce;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class V3EcommerceApplicationTests {

	@Test
	void contextLoads() {
	}

}
